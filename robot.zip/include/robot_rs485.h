#ifndef ROBOT_RS485_H
#define ROBOT_RS485_H

void rs485_init();
void rs485_run();
void rs485_report();

#endif