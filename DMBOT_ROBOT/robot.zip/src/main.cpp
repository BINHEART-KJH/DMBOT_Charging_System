#include <Arduino.h>
#include <ArduinoBLE.h>
#include "hmac.h"
#include "sha256.h"

const char *targetLocalName = "DM-STATION";
const char *sharedKey = "DM--010225";

char nonce[9];     // 8 chars + null
char tokenHex[17]; // 8 bytes = 16 hex chars + null

BLEDevice peripheral;
BLECharacteristic nonceChar;
BLECharacteristic authTokenChar;

// 추가 GATT 상태 캐릭터리스틱
BLECharacteristic batteryFullChar;
BLECharacteristic chargerOKChar;
BLECharacteristic bleConnectedChar;
BLECharacteristic chargerJumperChar;
BLECharacteristic batteryOKChar;

bool connected = false;
bool authenticated = false;
unsigned long lastStatusRead = 0;

void generateHMAC_SHA256(const char *key, const char *message, char *outputHex) {
  uint8_t hmacResult[32];
  HMAC hmac;
  hmac.init((const uint8_t *)key, strlen(key));
  hmac.update((const uint8_t *)message, strlen(message));
  hmac.finalize(hmacResult, sizeof(hmacResult));

  for (int i = 0; i < 8; ++i) {
    sprintf(&outputHex[i * 2], "%02x", hmacResult[i]);
  }
  outputHex[16] = '\0';
}

void setup() {
  Serial.begin(9600);
  delay(500);

  if (!BLE.begin()) {
    Serial.println("❌ BLE 초기화 실패!");
    return;
  }

  Serial.println("✅ BLE 초기화 완료 (Central 모드)");
  BLE.scan(true);
  Serial.println("🔍 BLE 스캔 시작");
}

void loop() {
  // 연결 끊김 감지 → 재스캔
  if (connected && peripheral && !peripheral.connected()) {
    Serial.println("🔌 연결 끊김 감지 → 재스캔");
    connected = false;
    authenticated = false;
    BLE.scan(true);
    return;
  }

  // BLE 스캔 및 연결
  if (!connected) {
    BLEDevice device = BLE.available();
    if (device && device.hasLocalName() && device.localName() == targetLocalName) {
      Serial.print("📡 발견된 장치: ");
      Serial.println(device.localName());

      BLE.stopScan();
      Serial.println("📶 연결 시도 중...");

      if (device.connect()) {
        delay(300);  // 연결 안정화
        Serial.println("✅ 연결 성공!");
        connected = true;
        peripheral = device;

        if (peripheral.discoverAttributes()) {
          delay(100); // GATT 안정화 대기
          Serial.println("🔍 GATT 속성 탐색 완료");

          // 인증 관련 캐릭터리스틱
          nonceChar     = peripheral.characteristic("2A03");
          authTokenChar = peripheral.characteristic("2A04");

          // GATT 상태 캐릭터리스틱
          batteryFullChar     = peripheral.characteristic("2A05");
          chargerOKChar       = peripheral.characteristic("2A06");
          bleConnectedChar    = peripheral.characteristic("2A07");
          chargerJumperChar   = peripheral.characteristic("2A08");
          batteryOKChar       = peripheral.characteristic("2A09");

          if (nonceChar && authTokenChar && nonceChar.canRead() && authTokenChar.canWrite()) {
            byte nonceBuf[20];
            int len = nonceChar.readValue(nonceBuf, sizeof(nonceBuf));

            if (len > 0 && len < sizeof(nonce)) {
              memcpy(nonce, nonceBuf, len);
              nonce[len] = '\0';

              Serial.print("📩 수신된 nonce: ");
              Serial.println(nonce);

              generateHMAC_SHA256(sharedKey, nonce, tokenHex);

              Serial.print("➡️ 전송할 HMAC 토큰: ");
              Serial.println(tokenHex);

              authTokenChar.writeValue((const unsigned char *)tokenHex, 16);
              Serial.println("✅ 토큰 전송 완료. 인증 대기 중...");
              authenticated = true;
              lastStatusRead = millis();
            } else {
              Serial.println("⚠️ nonce 읽기 실패");
              device.disconnect();
              connected = false;
              BLE.scan(true);
            }
          } else {
            Serial.println("❌ 캐릭터리스틱 접근 실패 (nonce/token)");
            device.disconnect();
            connected = false;
            BLE.scan(true);
          }
        } else {
          Serial.println("❌ GATT 속성 탐색 실패");
          device.disconnect();
          connected = false;
          BLE.scan(true);
        }
      } else {
        Serial.println("❌ 연결 실패");
        connected = false;
        BLE.scan(true);
      }
    }
  }

  // 인증 후 GATT 상태 polling (3초 주기)
  if (connected && authenticated && millis() - lastStatusRead >= 3000) {
    lastStatusRead = millis();

    if (batteryFullChar && chargerOKChar && bleConnectedChar && chargerJumperChar && batteryOKChar) {
      byte val;

      batteryFullChar.readValue(&val, 1);
      Serial.print("🔋 Battery Full: ");
      Serial.println(val ? "YES" : "NO");

      chargerOKChar.readValue(&val, 1);
      Serial.print("🔌 Charger OK: ");
      Serial.println(val ? "YES" : "NO");

      bleConnectedChar.readValue(&val, 1);
      Serial.print("📶 BLE Connected: ");
      Serial.println(val ? "YES" : "NO");

      chargerJumperChar.readValue(&val, 1);
      Serial.print("🔗 Charger Jumper Relay: ");
      Serial.println(val ? "ON" : "OFF");

      batteryOKChar.readValue(&val, 1);
      Serial.print("✅ Battery OK Relay: ");
      Serial.println(val ? "ON" : "OFF");

      Serial.println("---------------------------------");
    } else {
      Serial.println("⚠️ 일부 GATT 특성이 null입니다.");
    }
  }
}
