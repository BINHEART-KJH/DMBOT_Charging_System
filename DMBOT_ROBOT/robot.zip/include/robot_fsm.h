#ifndef ROBOT_FSM_H
#define ROBOT_FSM_H

void robotFSM_init();
void robotFSM_update();

#endif