// // robot_auth.cpp
// #include "robot_auth.h"
// #include "sha256.h"
// #include <string.h>
// #include <stdio.h>
