#include "robot_ble.h"
#include "robot_auth.h"
#include "robot_gpio.h"
#include <Arduino.h>

static BLEDevice central;
static unsigned long lastGATTReadTime = 0;
static bool connected = false;

const char* targetLocalName = "DMBOT-STATION";
const int GATT_READ_INTERVAL = 5000;

void robotBLE_init() {
  if (!BLE.begin()) {
    Serial.println("[BLE] BLE 초기화 실패");
    return;
  }

  BLE.setLocalName("DMBOT-ROBOT");
  BLE.setDeviceName("DMBOT-ROBOT");
  BLE.scan();
  Serial.println("[BLE] 스캔 시작");
}

void robotBLE_update() {
  if (!connected) {
    BLEDevice peripheral = BLE.available();
    if (peripheral && peripheral.hasLocalName() && peripheral.localName() == targetLocalName) {
      Serial.println("[BLE] Station 발견, 연결 시도 중...");
      BLE.stopScan();

      if (peripheral.connect()) {
        Serial.println("[BLE] 연결 성공");

        if (peripheral.discoverAttributes()) {
          Serial.println("[BLE] GATT 발견 성공");

          if (!robotAuth_bindCharacteristics(peripheral)) {
            Serial.println("[BLE] 인증 특성 바인딩 실패 → 연결 종료");
            peripheral.disconnect();
            BLE.scan();
            return;
          }

          central = peripheral;
          connected = true;
          lastGATTReadTime = millis();
          robotAuth_reset();  // 인증 상태 초기화
        } else {
          Serial.println("[BLE] GATT 탐색 실패, 연결 해제");
          peripheral.disconnect();
          BLE.scan();
        }
      } else {
        Serial.println("[BLE] 연결 실패, 재스캔");
        BLE.scan();
      }
    }
  } else {
    if (!central.connected()) {
      Serial.println("[BLE] 연결 끊김, 재스캔");
      connected = false;
      robotAuth_reset();
      robotGPIO_setRelay(false);  // 릴레이 OFF
      BLE.scan();
      return;
    }

    // 인증 시도
    robotAuth_update(central);

    // 인증 완료된 경우에만 GATT 상태 주기 체크
    if (isRobotAuthenticated()) {
      if (millis() - lastGATTReadTime >= GATT_READ_INTERVAL) {
        Serial.println("[BLE] GATT 상태 주기적 체크...");

        BLECharacteristic batteryChar = central.characteristic("battery_state_uuid");
        if (batteryChar && batteryChar.canRead()) {
          if (batteryChar.read()) {
            int value = batteryChar.value()[0];
            Serial.print("[BLE] Battery 상태: ");
            Serial.println(value);
          } else {
            Serial.println("[BLE] GATT 읽기 실패, 연결 해제");
            robotBLE_disconnect();
            BLE.scan();
            return;
          }
        } else {
          Serial.println("[BLE] battery_state_uuid characteristic 없음");
        }

        lastGATTReadTime = millis();
      }
    }
  }
}

bool robotBLE_isConnected() {
  return connected && central.connected();
}

bool robotBLE_isAuthenticated() {
  return isRobotAuthenticated();
}

void robotBLE_disconnect() {
  if (central && central.connected()) {
    central.disconnect();
  }
  connected = false;
  robotAuth_reset();
  robotGPIO_setRelay(false);  // 릴레이 OFF
}