#include <Arduino.h>
#include "robot_fsm.h"
#include "robot_ble.h"
#include "robot_gpio.h"
#include "robot_rs485.h"

void setup() {
  Serial.begin(9600);            // 디버깅용 Serial
  robotBLE_init();               // ✅ BLE 초기화
  robotFSM_init();               // ✅ FSM 초기화 (중복 제거됨)
}

void loop() {
  robotBLE_update();           // ✅ BLE 상태 관리 전담
  robotFSM_update();           // FSM 상태 업데이트
  robotRS485_update();      // FSM 내부에서 처리됨
}
