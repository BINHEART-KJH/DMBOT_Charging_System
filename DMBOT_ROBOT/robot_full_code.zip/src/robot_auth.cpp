// robot_auth.cpp
#include "robot_auth.h"
#include "hmac.h"
#include "sha256.h"
#include <Arduino.h>

static bool authenticated = false;
static BLECharacteristic remoteNonceChar;
static BLECharacteristic remoteTokenChar;

const char* secretKey = "DMBOT_SHARED_SECRET";

void robotAuth_reset() {
  authenticated = false;
}

bool isRobotAuthenticated() {
  return authenticated;
}

bool robotAuth_bindCharacteristics(BLEDevice& central) {
  remoteNonceChar = central.characteristic("0xAA11");
  remoteTokenChar = central.characteristic("0xAA12");

  if (!remoteNonceChar) {
    Serial.println("[AUTH] remoteNonceChar 못찾음");
    return false;
  }
  if (!remoteTokenChar) {
    Serial.println("[AUTH] remoteTokenChar 못찾음");
    return false;
  }

  if (!remoteNonceChar.canRead()) {
    Serial.println("[AUTH] nonceChar 읽기 권한 없음");
    return false;
  }
  if (!remoteTokenChar.canWrite()) {
    Serial.println("[AUTH] tokenChar 쓰기 권한 없음");
    return false;
  }

  return true;
}

void robotAuth_update(BLEDevice& central) {
  if (authenticated) return;

  if (!remoteNonceChar || !remoteTokenChar) {
    Serial.println("[AUTH] 인증 특성 바인딩 안됨 → 재시도 필요");
    return;
  }

  if (!remoteNonceChar.read()) {
    Serial.println("[AUTH] nonce 읽기 실패");
    return;
  }

  char nonce[33] = {0};
  memcpy(nonce, remoteNonceChar.value(), 32);
  nonce[32] = '\0';

  Serial.print("[AUTH] 받은 nonce: ");
  Serial.println(nonce);

  char token[65] = {0};
  generateHMAC_SHA256(nonce, secretKey, token);

  Serial.print("[AUTH] 생성한 token: ");
  Serial.println(token);

  if (!remoteTokenChar.writeValue((const uint8_t*)token, strlen(token))) {
    Serial.println("[AUTH] token 쓰기 실패");
    return;
  }

  authenticated = true;
  Serial.println("[AUTH] 토큰 전송 완료 → 인증 성공 처리");
}