#ifndef ROBOT_AUTH_H
#define ROBOT_AUTH_H

#include <ArduinoBLE.h>

void robotAuth_reset();
bool isRobotAuthenticated();
bool robotAuth_bindCharacteristics(BLEDevice& central);  // 선언 추가
void robotAuth_update(BLEDevice& central);

#endif