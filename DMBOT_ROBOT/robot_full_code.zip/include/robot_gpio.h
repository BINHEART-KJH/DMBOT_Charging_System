#ifndef ROBOT_GPIO_H
#define ROBOT_GPIO_H

void robotGPIO_init();
void robotGPIO_setRelay(bool on);

#endif