
#pragma once

#include "defs.h"
#include "crgb.h"

extern CRGB leds[NUM_LEDS];

void InitGraphics();
void GraphicsShow();